export const Role = {
  USER: 'user',
  MODEL: 'model',
};
